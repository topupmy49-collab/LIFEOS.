# LIFEOS — APK Build Guide (বাংলা)

## বর্তমান ZIP পরীক্ষার ফল
- Android/Kotlin/Jetpack Compose project structure আছে।
- Gradle Wrapper properties আছে: `gradle/wrapper/gradle-wrapper.properties`.
- কিন্তু `gradlew`, `gradlew.bat` এবং `gradle/wrapper/gradle-wrapper.jar` এই ZIP-এ নেই। তাই সাধারণভাবে `./gradlew assembleDebug` চালানো এখনই সম্ভব নয়।
- এই পরিবেশে Android SDK/Gradle build চালিয়ে APK compile করে যাচাই করা হয়নি। এই ZIP-কে তৈরি APK বা verified build হিসেবে ধরা যাবে না।

## শুধু Android ফোন থেকে চেষ্টা করার ধাপ
1. ZIP-টি ফোনে Extract করুন। `LIFEOS` project root-এ `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `gradle/` এবং `app/` থাকা উচিত।
2. Android project খোলার জন্য বিশ্বাসযোগ্য Android IDE/build environment ব্যবহার করুন। কোনো অজানা ওয়েবসাইট থেকে APK বা Gradle wrapper JAR ডাউনলোড করবেন না।
3. IDE যদি Gradle Wrapper missing দেখায়, আগে wrapper generate/restore করতে হবে। `gradle/wrapper/gradle-wrapper.properties`-এ নির্দিষ্ট Gradle distribution URL আছে, কিন্তু শুধু এই properties ফাইল wrapper-এর বিকল্প নয়।
4. Gradle sync/build সফল হলে `app` module-এর debug APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হয়।
5. APK তৈরি হওয়ার পরেই সেটি ইনস্টল করে Tasks, Notes, Finance, Goals, Habits এবং offline data persistence পরীক্ষা করুন।

## Build error হলে
সম্পূর্ণ error log বা স্ক্রিনশট পাঠান। প্রথম `What went wrong` / `Caused by` অংশটি সবচেয়ে জরুরি। শুধু Preview কাজ করা compile সফল হওয়ার প্রমাণ নয়।
